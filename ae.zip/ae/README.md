# Cuvée: Blending SMT-LIB with Programs and Weakest Preconditions

Dependencies: Java 8

Run

    ./cuvee-cvc4.sh examples/add.smt2
    ./cuvee-cvc4.sh examples/map.smt2
    ./cuvee-cvc4.sh examples/max.smt2
    ./cuvee-cvc4.sh examples/gcd.smt2

The output should be `unsat` in each case.
