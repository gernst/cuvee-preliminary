#!/bin/sh

java -jar cuvee.jar $@ -- ./cvc4-1.7-x86_64-linux-opt --lang smt2
