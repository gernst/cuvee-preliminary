#!/bin/sh

java -jar cuvee.jar $@
